package com.fiap.aosw.common;

public record ApiResponse(String message) { }
