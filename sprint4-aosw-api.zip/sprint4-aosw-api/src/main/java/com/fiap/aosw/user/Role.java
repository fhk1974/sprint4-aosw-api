package com.fiap.aosw.user;
public enum Role { ADMIN, USER }
